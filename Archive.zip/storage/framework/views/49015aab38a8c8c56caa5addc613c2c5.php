<html lang="en" class="dfark">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Create Your Free Portfolio Website in Minutes'); ?> - AmarDetails</title>

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('/images/favicon.ico')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <!-- style css -->
    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>
<body>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Back To Top Start -->
<button id="back-to-top" onclick="topFunction()"
        class="fixed text-xl rounded-full z-10 bottom-5 end-5 h-9 w-9 p-1 text-center bg-primary/20 text-primary flex justify-center items-center">
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M17 15L12 10L7 15" stroke="#027bff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
</button>
<!-- Back To Top End -->

<script src="<?php echo e(asset('/js/gumshoe.polyfills.min.js')); ?>"></script>

<!-- Theme Js -->
<script src="<?php echo e(asset('/js/theme.js')); ?>"></script>

</body>
</html>

<?php /**PATH /Users/arafatkn/projects/my/chatapp/resources/views/layouts/master.blade.php ENDPATH**/ ?>