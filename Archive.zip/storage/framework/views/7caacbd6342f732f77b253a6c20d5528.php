<!-- Footer section start -->
<footer class="bg-center bg-no-repeat bg-slate-900 bg-[url('../images/footer-bg.png')]">





































































































































    <div class="border-t border-slate-700/20 h-[75px]">
        <div
            class="container lg:px-20 flex flex-wrap justify-center items-center h-full  md:justify-between text-center md:text-start">
            <p class="text-base font-medium text-gray-400 flex items-center">
                <?php echo e(date('Y')); ?> © AmarDetails - Made with <i class="h-4 w-4 pl-2 text-red-500 fill-red-500"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg></i>
            </p>
            <p class="text-base font-medium text-gray-400">
                <a href="/pages/terms">Terms & Conditions</a> -
                <a href="/pages/privacy">Privacy Policy</a>
            </p>
        </div><!-- Flex End -->
    </div><!-- Container End -->
    </div>
</footer>
<!-- Footer section End -->
<?php /**PATH /Users/arafatkn/projects/my/chatapp/resources/views/partials/footer.blade.php ENDPATH**/ ?>