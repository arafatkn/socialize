<?php $__env->startSection('content'); ?>
<!-- Hero Section Start -->
<section id="home" class="relative overflow-hidden pt-40 pb-96 bg-gradient-to-r from-blue-100 to-blue-50 bg-opacity-50">
    <div class="container relative">
        <div class="text-center">
            <div class="flex justify-center mt-6">
                <div class="max-w-2xl">
                    <h1 class="text-5xl/tight text-gray-800 font-bold mb-10">
                        Create Your Free Portfolio Website in Minutes
                    </h1>
                    <p class="text-base text-gray-700 lg:max-w-md mx-auto"></p>
                </div>
            </div>

            <div class="">






                <a href="<?php echo e(route('user.dashboard')); ?>">
                <button
                    class="relative flex items-center justify-center gap-2.5 rounded-full text-base font-medium py-3.5 px-6 mt-10 mx-auto bg-primary text-white">
                    Create Free Portfolio Website
                </button>
                </a>
            </div>
        </div>
    </div><!-- Container End -->

    <div class="shape absolute sm:-bottom-px -bottom-[1px] start-0 end-0 overflow-hidden text-white">
        <svg class="w-full h-auto scale-[2.0] origin-top" viewBox="0 0 2880 48" fill="none"
             xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div><!-- end shap -->
</section>

<div class="pb-24">
    <div class="max-w-3xl mx-auto -mt-80 relative px-6 z-10">
        <div class="hidden lg:block">
            <div class="h-24 w-24 absolute -top-10 -end-5 -z-[1] bg-[url('../images/other/dot.svg')]"></div>
            <div class="h-24 w-24 absolute -bottom-10 -start-5 -z-[1] bg-[url('../images/other/dot2.svg')]"></div>
        </div>
        <img src="<?php echo e(asset('/images/landing/hero-img.png')); ?>" alt="" class="rounded-md w-full h-auto">
    </div>
</div>
<!-- Hero Section End -->



<!-- App Screens start -->
<section id="demo" class="pt-20 md:py-20">
    <div class="container">
        <div class="text-center max-w-xl mx-auto">
            <h6 class="font-normal uppercase mb-2">Demo <span class="font-semibold">Portfolios </span></h6>
            <h2 class="text-3xl font-semibold mb-3">Already Built Portfolios</h2>
            <p class="text-base font-normal text-gray-500">Checkout these featured dummy portfolios and get ideas how you can make better than these.</p>
        </div>

        <!-- Already Made -->
        <div class="mt-16">
            <div class="py-5 md:py-10 mb-8 md:mb-14 grid md:grid-cols-2 gap-2">
                <?php $__currentLoopData = ['arafat', 'arafatkn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="block relative hover:shadow-l h-96" href="//<?php echo e($portfolio); ?>.<?php echo e(config('app.domain')); ?>" target="_blank">

                        <iframe width="200%" height="200%" src="//<?php echo e($portfolio); ?>.<?php echo e(config('app.domain')); ?>" class="rounded-md border mx-auto scale-50 origin-top-left"></iframe>
                        <div
                            class="absolute bottom-0 left-0 right-0 top-0 h-full w-full overflow-hidden bg-blue-200 bg-fixed opacity-0 transition duration-300 ease-in-out hover:opacity-60"></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
        <!-- Demo end -->
    </div>
</section>
<!-- App Screens end -->









<!-- Watch Video Modal Start -->
<div id="watchvideomodal"
     class="hs-overlay hidden fixed top-0 left-0 z-[60] transition-all duration-500 fc-modal w-full h-full min-h-full items-center hs-overlay-open:flex">
    <div
        class="hs-overlay-open:opacity-100 duration-500 opacity-0 ease-out transition-[opacity] relative sm:max-w-2xl sm:w-full sm:mx-auto flex-col bg-white shadow-sm rounded-md overflow-hidden group">
        
        
        
        
    </div>
</div>
<!-- Watch Video Modal End -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arafatkn/projects/my/chatapp/resources/views/index.blade.php ENDPATH**/ ?>