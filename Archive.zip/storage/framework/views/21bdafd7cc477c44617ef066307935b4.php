<?php $__env->startSection('title', 'Terms of Service'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-32"></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arafatkn/projects/my/amardetails/resources/views/pages/privacy.blade.php ENDPATH**/ ?>