<?php $__env->startSection('title', 'Terms of Service'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mt-32 pb-32 text-center text-5xl">404</div>
    <div class="mb-32 text-center text-5xl">Not Found!</div>
    <div class="mt-16"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arafatkn/projects/my/chatapp/resources/views/errors/404.blade.php ENDPATH**/ ?>