<template>
  <div class="min-h-screen h-full bg-gray-50 justify-center items-center">
    <slot />
  </div>
</template>
