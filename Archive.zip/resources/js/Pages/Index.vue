<template>
  <XBox class="my-2.5">
    <XTextarea
      v-model="form.content"
      label="What's on your mind?"
      placeholder="Write something..."
      :errors="errors?.content"
    />

    <XButton label="Post Your Thoughts" color="primary" @click="postStatus" :loading="form.processing" />
  </XBox>

  <XBox v-for="post in posts.data" class="my-2.5">
    <div class="flex justify-between">
      <div class="font-medium">{{ post.user.name }}</div>
      <div class="text-sm text-gray-400">At {{ post.created_ago }}</div>
    </div>
    <p class="text-gray-600">{{ post.content }}</p>
  </XBox>

  <div class="flex gap-2 justify-center mt-10">
    <Link v-if="posts.links?.prev" :href="posts.links.prev"><XButton label="Prev Page" /></Link>
    <Link v-if="posts.links?.next" :href="posts.links.next"><XButton label="Next Page" /></Link>
  </div>
</template>
<script setup lang="ts">
import type { InertiaProps, PaginatedData, TimeStamp } from '@/types';
import type { User } from '@/types/user';
import XTextarea from '@/components/XTextarea.vue';
import { Link, useForm } from '@inertiajs/vue3';
import XBox from '@/components/XBox.vue';
import XButton from '@/components/XButton.vue';

type Post = {
  id: number;
  content: string;
  created_at: string;
  user: User;
  created_ago: string;
} & TimeStamp;

const props = defineProps<{ posts: PaginatedData<Post> } & InertiaProps>();

const form = useForm<{ content: string }>({ content: '' });

function postStatus() {
  form.post('/posts');
}
</script>
