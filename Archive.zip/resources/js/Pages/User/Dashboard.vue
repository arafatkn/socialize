<template>
  <div>Dashboard</div>
</template>
<script setup lang="ts"></script>
